import type { Achievement } from '../../../types';

export const ACHIEVEMENTS: Record<string, Achievement[]> = {
  streaks: [
    { id: 'streak_1', threshold: 1, title: 'ach_streak_1', icon: '✏️', tier: 'common' },
    { id: 'streak_3', threshold: 3, title: 'ach_streak_3', icon: '🔥', tier: 'common' },
    { id: 'streak_7', threshold: 7, title: 'ach_streak_7', icon: '📅', tier: 'rare' },
    { id: 'streak_10', threshold: 10, title: 'ach_streak_10', icon: '💪', tier: 'rare' },
    { id: 'streak_14', threshold: 14, title: 'ach_streak_14', icon: '🏆', tier: 'rare' },
    { id: 'streak_21', threshold: 21, title: 'ach_streak_21', icon: '😎', tier: 'rare' },
    { id: 'streak_30', threshold: 30, title: 'ach_streak_30', icon: '🌟', tier: 'legendary' },
    { id: 'streak_60', threshold: 60, title: 'ach_streak_60', icon: '🦾', tier: 'legendary' },
    { id: 'streak_90', threshold: 90, title: 'ach_streak_90', icon: '👑', tier: 'legendary' },
    { id: 'streak_180', threshold: 180, title: 'ach_streak_180', icon: '🐘', tier: 'legendary' },
    { id: 'streak_365', threshold: 365, title: 'ach_streak_365', icon: '🕰️', tier: 'legendary' },
  ],
  words: [
    { id: 'words_500', threshold: 500, title: 'ach_words_500', icon: '🚀', tier: 'common' },
    { id: 'words_1000', threshold: 1000, title: 'ach_words_1000', icon: '🦸', tier: 'common' },
    { id: 'words_2500', threshold: 2500, title: 'ach_words_2500', icon: '⚔️', tier: 'rare' },
    { id: 'words_5000', threshold: 5000, title: 'ach_words_5000', icon: '📖', tier: 'rare' },
    { id: 'words_10000', threshold: 10000, title: 'ach_words_10000', icon: '💯', tier: 'rare' },
    { id: 'words_25000', threshold: 25000, title: 'ach_words_25000', icon: '❤️', tier: 'rare' },
    { id: 'words_50000', threshold: 50000, title: 'ach_words_50000', icon: '📜', tier: 'legendary' },
    { id: 'words_100000', threshold: 100000, title: 'ach_words_100000', icon: '🧙', tier: 'legendary' },
    { id: 'words_250000', threshold: 250000, title: 'ach_words_250000', icon: '👁️', tier: 'legendary' },
    { id: 'words_500000', threshold: 500000, title: 'ach_words_500000', icon: '⚡', tier: 'legendary' },
  ],
  notes: [
    { id: 'notes_5', threshold: 5, title: 'ach_notes_5', icon: '💡', tier: 'common' },
    { id: 'notes_10', threshold: 10, title: 'ach_notes_10', icon: '🧠', tier: 'common' },
    { id: 'notes_25', threshold: 25, title: 'ach_notes_25', icon: '💎', tier: 'rare' },
    { id: 'notes_50', threshold: 50, title: 'ach_notes_50', icon: '📋', tier: 'rare' },
    { id: 'notes_100', threshold: 100, title: 'ach_notes_100', icon: '📚', tier: 'legendary' },
    { id: 'notes_250', threshold: 250, title: 'ach_notes_250', icon: '🔟0️⃣0️⃣', tier: 'legendary' },
  ],
  duration: [
    { id: 'duration_30', threshold: 30, title: 'ach_duration_30', icon: '⌛', tier: 'common' },
    { id: 'duration_60', threshold: 60, title: 'ach_duration_60', icon: '🕐', tier: 'rare' },
    { id: 'duration_180', threshold: 180, title: 'ach_duration_180', icon: '🕒', tier: 'legendary' },
  ]
};
