import { getLocalDb } from '../../../shared/lib/localDb';
import { StorageService } from './StorageService';
import { LocalDocumentService } from './LocalDocumentService';

export const SyncService = {
  async addToQueue(documentId: string): Promise<void> {
    const db = await getLocalDb();
    await db.put('syncQueue', {
      id: `sync_${documentId}_${Date.now()}`,
      documentId,
      type: 'document' as const,
      createdAt: Date.now(),
    });
  },

  async getPendingCount(): Promise<number> {
    const db = await getLocalDb();
    const all = await db.getAll('syncQueue');
    return all.filter(item => !item.id.startsWith('migrated_')).length;
  },

  async syncPending(userId: string): Promise<void> {
    const db = await getLocalDb();
    const queue = await db.getAll('syncQueue');
    const pending = queue.filter(item => !item.id.startsWith('migrated_'));

    if (pending.length === 0) return;

    const documentIds = [...new Set(pending.map(p => p.documentId))];

    for (const localId of documentIds) {
      try {
        const cloudId = await StorageService.addCloudCopy(userId, localId);
        await LocalDocumentService.updateLinkedCloudId(localId, cloudId);
      } catch (e) {
        console.error(`Sync failed for ${localId}:`, e);
      }
    }

    const tx = db.transaction('syncQueue', 'readwrite');
    await Promise.all(pending.map(p => tx.store.delete(p.id)));
    await tx.done;
  },

  async syncOne(userId: string, localId: string): Promise<string> {
    const cloudId = await StorageService.addCloudCopy(userId, localId);
    await LocalDocumentService.updateLinkedCloudId(localId, cloudId);
    return cloudId;
  },

  async maybeSyncAfterSave(userId: string, localId: string, autoSync: boolean): Promise<void> {
    if (!autoSync) return;
    await SyncService.addToQueue(localId);
    await SyncService.syncPending(userId);
  },
};
