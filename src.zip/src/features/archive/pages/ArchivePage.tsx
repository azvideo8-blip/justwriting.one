import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'motion/react';
import { User } from 'firebase/auth';
import { format } from 'date-fns';
import { ru, enUS } from 'date-fns/locale';
import { History, Search, LayoutGrid, LayoutList, BookOpen } from 'lucide-react';
import { Session, UserProfile } from '../../../types';
import { SessionCard } from '../../writing/components/SessionCard';
import { getSessionDate, cn } from '../../../core/utils/utils';
import { LocalDocumentService } from '../../writing/services/LocalDocumentService';
import { LocalVersionService } from '../../writing/services/LocalVersionService';
import { getOrCreateGuestId } from '../../../shared/lib/localDb';
import { AdaptiveContainer } from '../../../shared/components/Layout/AdaptiveContainer';
import { TagCloud } from '../../writing/components/TagCloud';
import { useLanguage } from '../../../core/i18n';
import { useArchiveFilters } from '../hooks/useArchiveFilters';
import { useArchiveSearch } from '../hooks/useArchiveSearch';
import { useNavigate } from 'react-router-dom';
import { EmptyState } from '../../../shared/components/EmptyState';

interface ArchiveViewProps {
  user: User | null;
  profile: UserProfile | null;
}

export function ArchivePage({ user, profile }: ArchiveViewProps) {
  const { t, language } = useLanguage();
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const userId = user?.uid ?? getOrCreateGuestId();

  const fetchSessions = async (isInitial = false) => {
    if (!isInitial) return;
    setLoading(true);
    setError(null);

    try {
      const localDocs = await LocalDocumentService.getGuestDocuments(userId);
      const sessionsWithContent = await Promise.all(
        localDocs.map(async (doc) => {
          const content = await LocalVersionService.getLatestContent(doc.id);
          return {
            id: doc.id,
            userId: doc.guestId,
            authorName: '',
            authorPhoto: '',
            content,
            duration: doc.totalDuration,
            wordCount: doc.totalWords,
            charCount: 0,
            wpm: 0,
            isPublic: false,
            title: doc.title,
            tags: doc.tags,
            createdAt: new Date(doc.lastSessionAt),
            _isLocal: true,
          } as Session & { _isLocal?: boolean };
        })
      );
      setSessions(sessionsWithContent);
    } catch (err) {
      console.error('Archive load error:', err);
      setError(t('archive_load_error'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSessions(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const { 
    selectedDate, setSelectedDate, 
    setSelectedMonth, 
    selectedTags, setSelectedTags,
    filteredSessions: filteredByFilters
  } = useArchiveFilters(sessions);
  const { 
    searchQuery, setSearchQuery, 
    searchedSessions: filteredSessions 
  } = useArchiveSearch(filteredByFilters);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>(() => (localStorage.getItem('archive_viewMode') as 'list' | 'grid') || 'list');
  
  useEffect(() => {
    localStorage.setItem('archive_viewMode', viewMode);
  }, [viewMode]);

  const allTags = useMemo(() => Array.from(new Set(sessions.flatMap(s => s.tags || []))), [sessions]);
  
  const groupedSessions = useMemo(() => {
    return filteredSessions.reduce((acc, session) => {
      const date = getSessionDate(session);
      const dateKey = format(date, 'yyyy-MM-dd');
      if (!acc[dateKey]) acc[dateKey] = [];
      acc[dateKey].push(session);
      return acc;
    }, {} as Record<string, Session[]>);
  }, [filteredSessions]);

  const sortedDates = useMemo(() => Object.keys(groupedSessions).sort((a, b) => new Date(b).getTime() - new Date(a).getTime()), [groupedSessions]);

  const dateLocale = language === 'ru' ? ru : enUS;

  return (
    <AdaptiveContainer>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12 pb-10"
      >
        <div className="flex flex-col md:flex-row gap-8 items-start">
          {/* Sidebar — appears first on mobile via order-first, second on desktop */}
          <div className="w-full md:w-80 shrink-0 space-y-8 order-first md:order-last">
            <div className="p-6 rounded-3xl space-y-4 transition-all bg-surface-card backdrop-blur-xl border border-border-subtle">
              <div className="flex items-center gap-2 border-b pb-2 border-border-subtle">
                <Search size={18} className="text-text-main/50" />
                <input 
                  type="text" 
                  value={searchQuery} 
                  onChange={e => setSearchQuery(e.target.value)} 
                  placeholder={t('archive_search_placeholder')} 
                  className="w-full bg-transparent outline-none text-sm text-text-main placeholder:text-text-main/40"
                />
              </div>
            </div>

            <TagCloud 
              tags={allTags} 
              selectedTags={selectedTags} 
              onToggleTag={(tag) => setSelectedTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag])} 
            />
          </div>

          {/* Sessions list — appears second on mobile, first on desktop */}
          <div className="flex-1 space-y-8 order-last md:order-first">
            <div className="flex items-center justify-between gap-4">
              <h3 className="text-2xl font-bold flex items-center gap-2 text-text-main">
                <History size={24} />
                {t('nav_notes')}
              </h3>

              <div className="flex p-1 rounded-2xl bg-surface-base/10 border border-border-subtle">
                <button 
                  onClick={() => setViewMode('list')}
                  className={cn(
                    "p-2 rounded-lg transition-all",
                    viewMode === 'list' 
                      ? "bg-surface-base/20 text-text-main shadow-sm" 
                      : "text-text-main/50 hover:text-text-main"
                  )}
                  title={t('archive_list')}
                  aria-label={t('archive_list')}
                >
                  <LayoutList size={18} />
                </button>
                <button 
                  onClick={() => setViewMode('grid')}
                  className={cn(
                    "p-2 rounded-lg transition-all",
                    viewMode === 'grid' 
                      ? "bg-surface-base/20 text-text-main shadow-sm" 
                      : "text-text-main/50 hover:text-text-main"
                  )}
                  title={t('archive_grid')}
                  aria-label={t('archive_grid')}
                >
                  <LayoutGrid size={18} />
                </button>
              </div>
            </div>
              
              <div className="space-y-6">
                {loading ? (
                  <div className="italic text-center py-12 text-text-main/70">{t('archive_loading')}</div>
                ) : error ? (
                  <div className="p-12 text-center rounded-3xl border bg-red-500/10 border-red-500/30">
                    <p className="text-red-400">{error}</p>
                  </div>
                ) : filteredSessions.length === 0 ? (
                  <EmptyState
                    icon={BookOpen}
                    title={t('archive_empty_title')}
                    description={t('archive_empty_subtitle')}
                  />
                ) : (
                  sortedDates.map(dateKey => (
                    <div key={dateKey} className="space-y-4">
                      <h4 className="text-lg font-bold text-text-main/70">{format(new Date(dateKey), 'd MMMM yyyy', { locale: dateLocale })}</h4>
                      <div className={cn(
                        "gap-6",
                        viewMode === 'grid' ? "grid grid-cols-1 md:grid-cols-2" : "flex flex-col"
                      )}>
                        {groupedSessions[dateKey].map(session => (
                          <SessionCard 
                            key={session.id} 
                            session={session} 
                            labels={profile?.labels || []}
                            onContinue={() => navigate('/', { state: { sessionToContinue: session } })}
                            searchQuery={searchQuery}
                            onDeleteSuccess={(id) => setSessions(prev => prev.filter(s => s.id !== id))}
                          />
                        ))}
                      </div>
                    </div>
                  ))
                 )}
               </div>
            </div>
        </div>
      </motion.div>
    </AdaptiveContainer>
  );
}
